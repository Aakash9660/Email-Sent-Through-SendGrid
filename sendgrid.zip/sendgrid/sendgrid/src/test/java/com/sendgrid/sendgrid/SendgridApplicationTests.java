package com.sendgrid.sendgrid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SendgridApplicationTests {

	@Test
	void contextLoads() {
	}

}
