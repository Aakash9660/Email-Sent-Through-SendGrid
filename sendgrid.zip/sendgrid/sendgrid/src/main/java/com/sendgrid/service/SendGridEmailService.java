package com.sendgrid.service;

import java.io.IOException;
import java.util.List;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.sendgrid.Content;
import com.sendgrid.Email;
import com.sendgrid.Mail;
import com.sendgrid.Method;
import com.sendgrid.Personalization;
import com.sendgrid.Request;
import com.sendgrid.Response;
import com.sendgrid.SendGrid;

@Service
public class SendGridEmailService {

	@Value("${sendGridAPIKey}")
	private String apiKey;

	@Value("${sendGridBulkEmailSender}")
	private String sendGridBulkEmailSender;
	private static final Logger logging = LoggerFactory.getLogger(SendGridEmailService.class);

	public ResponseEntity<?> sendGridEmail() {
		Email from = new Email(sendGridBulkEmailSender);
		List<String> to = List.of("smartdocsapp1@gmail.com", "smartdocsapp2@gmail.com", "smartdocsapp3@gmail.com",
				"smartdocsapp4@gmail.com", "smartdocsapp5@gmail.com", "smartdocsapp6@gmail.com",
				"smartdocsapp7@gmail.com", "smartdocsapp8@gmail.com", "smartdocsapp9@gmail.com",
				"smartdocsapp10@gmail.com", "smartdocsapp1@yahoo.com", "smartdocsapp2@yahoo.com",
				"smartdocsapp3@yahoo.com", "smartdocsapp4@yahoo.com", "smartdocsapp5@yahoo.com",
				"smartdocsapp6@yahoo.com", "smartdocsapp7@yahoo.com", "smartdocsapp8@yahoo.com",
				"smartdocsapp9@yahoo.com", "smartdocsapp10@yahoo.com", "smartdocsapp1@smartdocs.ai",
				"smartdocsapp2@smartdocs.ai", "smartdocsapp3@smartdocs.ai", "smartdocsapp4@smartdocs.ai",
				"smartdocsapp5@smartdocs.ai", "smartdocsapp6@smartdocs.ai", "smartdocsapp7@smartdocs.ai",
				"smartdocsapp8@smartdocs.ai", "smartdocsapp9@smartdocs.ai", "smartdocsapp10@smartdocs.ai");
		
		List<String> subjects = List.of("Subject-1", "Subject-2", "Subject-3", "Subject-4", "Subject-5", "Subject-6",
				"Subject-7", "Subject-8", "Subject-9", "Subject-10", "Subject-11", "Subject-12", "Subject-13",
				"Subject-14", "Subject-15");
		List<String> comments = List.of("Comment-1","Comment-2","Comment-3","Comment-4","Comment-5","Comment-6","Comment-7","Comment-8","Comment-9","Comment-10","Comment-11","Comment-12","Comment-13","Comment-14","Comment-15");
		Mail mail = new Mail();
		for (int i = 0; i < to.size(); i++) {
			Personalization personalization = new Personalization();
			personalization.addTo(new Email(to.get(i)));
			mail.addPersonalization(personalization);
		}
		mail.setFrom(from);
		Random random = new Random();
		int randomCommentsIndex = random.nextInt(comments.size());
		String comment = comments.get(randomCommentsIndex);
		Content content = new Content("text/html",
				"Vendor,\r\n"
				+ " \r\n"
				+ "<p><b>Why was the email sent to me?</b> </p>\r\n"
				+ "\r\n"
				+ "<p>Pennsylvania Turnpike Commission has an announcement for you.  </p>\r\n"
				+ "\r\n"
				+ "<p><b>What action do I need to take?  </b></p>\r\n"
				+ "\r\n"
				+ "<p>Please go to the vendor portal dashboard to find the details of the announcement.\r\n"
				+ "</p>\r\n"
				+ "\r\n"
				+ "<p><b>Announcement Details:  </b></p>\r\n"+comment
				+ "<b>\r\n"
				+ "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\" >\r\n"
				+ "    <tr>\r\n"
				+ "        <td align=\"center\" valign=\"top\">\r\n"
				+ "            <table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" style=\"float: left;\"  >\r\n"
				+ "                <tr>\r\n"
				+ "                    <td align=\"center\" valign=\"top\">Announcement </td> <td align=\"center\" valign=\"top\"> </td>\r\n"
				+ "                </tr>\r\n"
				+ "                \r\n"
				+ "\r\n"
				+ "            </table>\r\n"
				+ "        </td>\r\n"
				+ "    </tr>\r\n"
				+ "</table></b>");
		mail.addContent(content);
		int randomSubjectsIndex = random.nextInt(subjects.size());
		String subject = subjects.get(randomSubjectsIndex);
		mail.setSubject(subject);
		SendGrid sg = new SendGrid(apiKey);
		Request request = new Request();
		Response response = null;
		try {
			request.setMethod(Method.POST);
			request.setEndpoint("mail/send");
			request.setBody(mail.build());
			response = sg.api(request);
			logging.info("Response: {}", response);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return ResponseEntity.ok(response);
	}

	

}
