package com.sendgrid.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sendgrid.service.SendGridEmailService;

@RestController
public class SendGridEmailRestController {

	@Autowired
	private SendGridEmailService sendGridEmailService;

	@GetMapping(value = "/send")
	public String sendGrid() {
		sendGridEmailService.sendGridEmail();
		return "Send";
	}

}
